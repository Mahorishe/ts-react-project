import { MainPageAsync } from './ui/MainPage.async';

export {
    MainPageAsync as MainPage,
};
